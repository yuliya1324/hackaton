from UserPart import user_part

if __name__ == '__main__':
    user_part()
